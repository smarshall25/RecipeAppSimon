package com.example.recipeapp.ui

import androidx.compose.runtime.Composable
import androidx.navigation.compose.rememberNavController
import com.example.recipeapp.models.Recipe
import com.example.recipeapp.navigation.AppNavigation

@Composable
fun App() {
    val navController = rememberNavController()
    val recipes = mutableListOf(
        Recipe("Pasta", "Delicious pasta", listOf("Noodles", "Tomato Sauce", "Cheese")),
        Recipe("Salad", "Fresh salad", listOf("Lettuce", "Tomato", "Cucumber"))
    )

    AppNavigation(
        navController = navController,
        recipes = recipes,
        onRecipeAdded = { recipe ->
            recipes.add(recipe)
        }
    )
}
