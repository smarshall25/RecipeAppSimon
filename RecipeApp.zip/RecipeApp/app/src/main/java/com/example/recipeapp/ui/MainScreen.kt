package com.example.recipeapp.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.recipeapp.models.Recipe
import com.example.recipeapp.navigation.AppNavigation
import com.example.recipeapp.ui.screens.screens.Screen
import androidx.navigation.NavController
import androidx.navigation.NavHostController

@Composable
fun MainScreen() {
    val navController = rememberNavController()
    val recipes = remember { mutableStateListOf(
        Recipe("Pasta", "Delicious pasta", listOf("Noodles", "Tomato Sauce", "Cheese")),
        Recipe("Salad", "Fresh salad", listOf("Lettuce", "Tomato", "Cucumber"))
    ) }

    Scaffold(
        bottomBar = {
            NavigationBar(navController)
        }
    ) { innerPadding ->
        AppNavigation(
            navController = navController,
            recipes = recipes,
            onRecipeAdded = { recipe ->
                recipes.add(recipe)
                navController.navigate(Screen.Home.route) {
                    popUpTo(Screen.Home.route) { inclusive = true }
                }
            },
            modifier = Modifier.padding(innerPadding)
        )
    }
}

@Composable
fun NavigationBar(navController: NavHostController) {
    NavigationBar {
        val currentBackStackEntry by navController.currentBackStackEntryAsState()
        val currentDestination = currentBackStackEntry?.destination
        val items = listOf(Screen.Home, Screen.Profile, Screen.Settings)
        items.forEach { screen ->
            NavigationBarItem(
                icon = { Icon(screen.icon, contentDescription = null) },
                label = { Text(screen.route) },
                selected = currentDestination?.route == screen.route,
                onClick = {
                    navController.navigate(screen.route) {
                        popUpTo(navController.graph.startDestinationId)
                        launchSingleTop = true
                    }
                }
            )
        }
    }
}
