package com.example.recipeapp.ui.screens.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.recipeapp.models.Recipe

@Composable
fun ProfileScreen(onRecipeAdded: (Recipe) -> Unit) {
    var name by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var ingredients by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = "Add a Recipe", style = MaterialTheme.typography.headlineSmall)
        Spacer(modifier = Modifier.height(16.dp))
        BasicTextField(value = name, onValueChange = { name = it }, modifier = Modifier.fillMaxWidth().padding(8.dp), decorationBox = { innerTextField ->
            Box(modifier = Modifier.padding(8.dp)) {
                if (name.isEmpty()) Text(text = "Name")
                innerTextField()
            }
        })
        BasicTextField(value = description, onValueChange = { description = it }, modifier = Modifier.fillMaxWidth().padding(8.dp), decorationBox = { innerTextField ->
            Box(modifier = Modifier.padding(8.dp)) {
                if (description.isEmpty()) Text(text = "Description")
                innerTextField()
            }
        })
        BasicTextField(value = ingredients, onValueChange = { ingredients = it }, modifier = Modifier.fillMaxWidth().padding(8.dp), decorationBox = { innerTextField ->
            Box(modifier = Modifier.padding(8.dp)) {
                if (ingredients.isEmpty()) Text(text = "Ingredients (comma separated)")
                innerTextField()
            }
        })
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = {
            onRecipeAdded(Recipe(name, description, ingredients.split(",").map { it.trim() }))
            name = ""
            description = ""
            ingredients = ""
        }) {
            Text(text = "Add Recipe")
        }
    }
}
