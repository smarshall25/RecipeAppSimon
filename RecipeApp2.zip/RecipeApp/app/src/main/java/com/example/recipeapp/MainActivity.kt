package com.example.recipeapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import com.example.recipeapp.ui.App
import com.example.recipeapp.ui.theme.RecipeAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefHelper = PreferenceHelper(applicationContext)
        setContent {
            RecipeAppTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    App(prefHelper)
                }
            }
        }
    }
}
