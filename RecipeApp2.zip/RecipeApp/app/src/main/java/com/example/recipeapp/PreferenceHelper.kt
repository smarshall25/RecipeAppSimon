package com.example.recipeapp

import android.content.Context
import android.content.SharedPreferences
import com.example.recipeapp.models.Recipe
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class PreferenceHelper(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("recipe_prefs", Context.MODE_PRIVATE)

    fun saveRecipes(recipes: List<Recipe>) {
        val editor = prefs.edit()
        val gson = Gson()
        val json = gson.toJson(recipes)
        editor.putString("recipes", json)
        editor.apply()
    }

    fun getRecipes(): List<Recipe> {
        val gson = Gson()
        val json = prefs.getString("recipes", null)
        val type = object : TypeToken<List<Recipe>>() {}.type
        return if (json != null) gson.fromJson(json, type) else emptyList()
    }
}
