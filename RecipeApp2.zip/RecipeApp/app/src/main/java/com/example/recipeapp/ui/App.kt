package com.example.recipeapp.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import com.example.recipeapp.PreferenceHelper
import com.example.recipeapp.models.Recipe
import com.example.recipeapp.ui.MainScreen

@Composable
fun App(prefHelper: PreferenceHelper) {
    val recipes = remember { mutableStateListOf<Recipe>() }
    recipes.addAll(prefHelper.getRecipes())

    fun addRecipe(recipe: Recipe) {
        recipes.add(recipe)
        prefHelper.saveRecipes(recipes)
    }

    MainScreen(recipes = recipes, onRecipeAdded = { recipe ->
        addRecipe(recipe)
    })
}
