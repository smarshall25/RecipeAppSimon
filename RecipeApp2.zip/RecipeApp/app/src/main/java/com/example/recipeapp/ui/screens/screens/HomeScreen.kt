package com.example.recipeapp.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.recipeapp.models.Recipe
import com.example.recipeapp.ui.screens.screens.RecipeCard

@Composable
fun HomeScreen(recipes: List<Recipe>) {
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp)
    ) {
        Text(
            text = "Home Screen",
            style = MaterialTheme.typography.headlineMedium, // updated to Material 3 naming
            modifier = Modifier.padding(bottom = 16.dp)
        )
        recipes.forEach { recipe ->
            RecipeCard(recipe)
            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}
