package com.example.recipeapp

import android.content.Context
import android.content.SharedPreferences
import com.example.recipeapp.models.Recipe
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class PreferenceHelper(context: Context) {

    private val sharedPreferences: SharedPreferences =
        context.getSharedPreferences("recipes_prefs", Context.MODE_PRIVATE)

    private val gson = Gson()

    fun saveRecipes(recipes: List<Recipe>) {
        val json = gson.toJson(recipes)
        sharedPreferences.edit().putString("recipes", json).apply()
    }

    fun getRecipes(): List<Recipe> {
        val json = sharedPreferences.getString("recipes", null) ?: return emptyList()
        val type = object : TypeToken<List<Recipe>>() {}.type
        return gson.fromJson(json, type)
    }
}
