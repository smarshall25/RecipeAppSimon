package com.example.recipeapp.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.rememberNavController
import com.example.recipeapp.PreferenceHelper
import com.example.recipeapp.models.Recipe
import com.example.recipeapp.ui.theme.RecipeAppTheme
import com.example.recipeapp.navigation.AppNavigation

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            RecipeAppTheme {
                val preferenceHelper = PreferenceHelper(LocalContext.current)
                val recipes = remember { mutableStateListOf<Recipe>() }

                LaunchedEffect(Unit) {
                    recipes.addAll(preferenceHelper.getRecipes())
                }

                val navController = rememberNavController()

                fun onRecipeAdded(recipe: Recipe) {
                    recipes.add(recipe)
                    preferenceHelper.saveRecipes(recipes)
                }

                fun onRecipeRemove(recipe: Recipe) {
                    recipes.remove(recipe)
                    preferenceHelper.saveRecipes(recipes)
                }

                AppNavigation(
                    navController = navController,
                    recipes = recipes,
                    onRecipeAdded = ::onRecipeAdded,
                    onRecipeRemoved = ::onRecipeRemove
                )
            }
        }
    }
}
