package com.example.recipeapp.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.recipeapp.PreferenceHelper
import com.example.recipeapp.models.Recipe
import com.example.recipeapp.navigation.AppNavigation
import com.example.recipeapp.navigation.Screen

@Composable
fun MainScreen() {
    val navController = rememberNavController()
    val context = LocalContext.current
    val preferenceHelper = remember { PreferenceHelper(context) }
    val recipes = remember { mutableStateListOf<Recipe>() }

    LaunchedEffect(Unit) {
        recipes.addAll(preferenceHelper.getRecipes())
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route

                listOf(Screen.Home, Screen.Profile, Screen.Settings).forEach { screen ->
                    NavigationBarItem(
                        icon = { Icon(screen.icon, contentDescription = null) },
                        label = { Text(screen.route) },
                        selected = currentRoute == screen.route,
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.startDestinationId) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        AppNavigation(
            navController = navController,
            modifier = Modifier.padding(innerPadding),
            recipes = recipes,
            onRecipeAdded = { recipe ->
                recipes.add(recipe)
                preferenceHelper.saveRecipes(recipes)
                navController.navigate(Screen.Home.route)
            },
            onRecipeRemoved = { recipe ->
                recipes.remove(recipe)
                preferenceHelper.saveRecipes(recipes)
            }
        )
    }
}
