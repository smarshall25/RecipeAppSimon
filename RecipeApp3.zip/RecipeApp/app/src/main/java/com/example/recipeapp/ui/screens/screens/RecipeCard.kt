package com.example.recipeapp.ui.screens.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.Button
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.recipeapp.models.Recipe

@Composable
fun RecipeCard(
    recipe: Recipe,
    onRecipeRemove: (Recipe) -> Unit
) {
    Card(
        modifier = Modifier
            .padding(8.dp)
            .fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(text = recipe.name, style = MaterialTheme.typography.headlineSmall)
            Text(text = recipe.description, style = MaterialTheme.typography.bodyLarge)
            recipe.ingredients.forEach { ingredient ->
                Text(text = ingredient, style = MaterialTheme.typography.bodyMedium)
            }
            Button(
                onClick = { onRecipeRemove(recipe) },
                modifier = Modifier.padding(top = 8.dp)
            ) {
                Text("Remove")
            }
        }
    }
}
